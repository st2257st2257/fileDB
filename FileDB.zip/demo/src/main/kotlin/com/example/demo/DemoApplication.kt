import java.sql.DriverManager
import java.util.Properties

fun checkConnection() {

	// the model class
	data class User(val id: Int, val date: String, val time: String, val temp: String)

	Class.forName("org.postgresql.Driver")

	val jdbcUrl = "jdbc:postgresql://rc1b-lyikh6bdnx93n0uz.mdb.yandexcloud.net:6432/db1"

	var properties = Properties()
	properties.setProperty( "ssl", "true" )
	properties.setProperty( "user", "user1" )
	properties.setProperty( "password", "wacze000" )
	properties.setProperty( "target_session_attrs"," read-write" )
	properties.setProperty( "sslmode", "require" )
	properties.put("connectTimeout", "10000");

	val connection = DriverManager.getConnection(jdbcUrl, properties)

	// prints true if the connection is valid
	println(connection.isValid(0))

	// the query is only prepared not executed
	var query = connection.prepareStatement("CREATE TABLE  public.users_2 (\n" +
			"    id bigint NOT NULL,\n" +
			"    name1 VARCHAR(255),\n" +
			"    name2 VARCHAR(255),\n" +
			"    name3 VARCHAR(255),\n" +
			"    PRIMARY KEY (id)" +
			")\n")

	// the query is executed and results are fetched
	try {
		query.executeQuery()
	} catch ( e: Exception ) {
		println(e)
	}

	query = connection.prepareStatement("INSERT INTO public.users_2 (id, name1, name2, name3) VALUES (350, '1000', '25', '25')")
	try {
		query.executeQuery()
	} catch ( e: Exception ) {
		println(e)
	}
	query = connection.prepareStatement("INSERT INTO public.users_2 (id, name1, name2, name3) VALUES (351, '1003', '23', '23')")
	try {
		query.executeQuery()
	} catch ( e: Exception ) {
		println(e)
	}
	query = connection.prepareStatement("INSERT INTO public.users_2 (id, name1, name2, name3) VALUES (352, '990', '27', '27')")
	try {
		query.executeQuery()
	} catch ( e: Exception ) {
		println(e)
	}
	query = connection.prepareStatement("INSERT INTO public.users_2 (id, name1, name2, name3) VALUES (353, '1190', '22', '22')")
	try {
		query.executeQuery()
	} catch ( e: Exception ) {
		println(e)
	}

	// the query is only prepared not executed
	query = connection.prepareStatement("SELECT * FROM public.users_2")

	// the query is executed and results are fetched
	val result = query.executeQuery()

	// an empty list for holding the results
	val users = mutableListOf<User>()

	while (result.next()) {
		val id = result.getInt("id")
		val name1 = result.getString("name1")
		val name2 = result.getString("name2")
		val name3 = result.getString("name3")
		users.add(User(id, name1, name2, name3))
	}
	println(users)

}



fun main() {

	checkConnection()

}